Installation
============

PyPI
----
Install MESA by running::

    pip install mesa

Conda
-----
Install MESA via Conda as::

    conda install -c conda-forge mesa
